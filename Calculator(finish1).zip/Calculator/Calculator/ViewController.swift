//
//  ViewController.swift
//  Calculator
//
//  Created by Pasha Moroz on 3/14/19.
//  Copyright © 2019 Pavel Moroz. All rights reserved.
//

import UIKit

///Красивый вывод расширение
extension Formatter {
    static let withSeparator: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.groupingSeparator = " "
        formatter.numberStyle = .decimal
        return formatter
    }()
}
extension Double {
    var formattedWithSeparator: String {
        return Formatter.withSeparator.string(for: self) ?? ""
    }
}
/// конец расширения

class ViewController: UIViewController {
    
  
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var logLabel: UILabel!
    
    //Кнопки
    @IBOutlet weak var buttonPlus: UIButton!
    
    
    var massiveOfNumber : String = ""
    
    //Переменные для вычислений
    var massiveOfValue : [Double] = []
    var result : [Double] = []
    var indexSum = 0
    
    //проверка нажатой кнопки
    var tappedNummber = false
    
    var realNumbers = 0.0
    
    ///логи
    var resultLog : [String] = []

    ///знаки
    var signPlus : [String:Bool] = ["plus":false,"minus":false,"division":false,
                                    "signСhange":false, "squareRoot":false, "square":false,
                                    "percent":false]
    
    ///какой знак нажал в первый раз
    var signFirst = ""
    var signThis = ""
    
    
    ///Функция добавляет пробел между цифрами
    func updateMassive (string:String)->String {
 
        var someString = string
        someString = Double(someString)!.formattedWithSeparator
        return someString
    }
    

    /// Удаляет последние введенное число
    @IBAction func delate(_ sender: UIButton) {

        if massiveOfNumber.isEmpty {
          resultLabel.text = "0"
        } else {
            massiveOfNumber.removeLast()
            if massiveOfNumber.isEmpty  {
             resultLabel.text = "0"
            } else {
            resultLabel.text =  updateMassive(string: massiveOfNumber)
            }
        }
    }
    
    
    //Чистим память
    @IBAction func delateAll(_ sender: UIButton) {
        massiveOfValue.removeAll()
        result.removeAll()
        resultLog.removeAll()
        logLabel.text = ""
        massiveOfNumber = ""
        tappedNummber = false
        resultLabel.text = "0"
        
        //здесь сбрасываем все знаки
        signPlus["plus"] = false
        signPlus["minus"] = false
        signPlus["division"] = false
        signPlus["signСhange"] = false
        signPlus["squareRoot"] = false
        signPlus["square"] = false
        signPlus["percent"] = false
        
        signFirst = ""
        signThis = ""
        
    }
    
    
    ///НАЧАЛО КНОПОК 1 - 0
    @IBAction func numberButtunTapped(_ sender: UIButton) {
        guard let number = sender.titleLabel?.text else {return}
        massiveOfNumber =  massiveOfNumber + number
        let someRealNumbers = Double(massiveOfNumber)
        realNumbers = someRealNumbers ?? 0
        resultLabel.text = updateMassive(string: massiveOfNumber)
        tappedNummber = true
        }
    ///КОНЕЦ КНОПОК 1 - 0
    
    
    ////Сумма
    @IBAction func sum(_ sender: UIButton) {

        guard let doubleValue = Double(resultLabel.text!.filter("0123456789.-".contains))  else {return}
        
      massiveOfNumber = ""
      signThis = "plus"
        print(signThis)
        
        if signFirst.isEmpty {
            signFirst = signThis
        }
        
       
        ///Ставим знак+ //для знака =
        signPlus["plus"] = true
        signPlus["minus"] = false
        signPlus["division"] = false
        signPlus["square"] = false
        signPlus["percent"] = false
        
 ///проверка того, что мы вводим новые цифры.
        if tappedNummber == true {
        massiveOfValue.append(doubleValue)
        indexSum = massiveOfValue.count

        resultLog.append("\(massiveOfValue[0])+")
        for i in resultLog {
                logLabel.text = "\(i)"
            }
        }

        tappedNummber = false
        
}
    
    ///знак минус
    @IBAction func minus(_ sender: UIButton) {
        guard let doubleValue = Double(resultLabel.text!.filter("0123456789.-".contains))  else {return}
        
        massiveOfNumber = ""
        signThis = "minus"
        print(signThis)
        
        if signFirst.isEmpty {
            signFirst = signThis
        }
        
        
        ///Ставим знак-
        signPlus["minus"] = true
        signPlus["plus"] = false
        signPlus["division"] = false
        signPlus["square"] = false
        signPlus["percent"] = false
        //signPlus["signСhange"] = false
        //signPlus["squareRoot"] = false
        
        
        
        
        ///проверка того, что мы вводим новые цифры.
        if tappedNummber == true {
            massiveOfValue.append(doubleValue)
            indexSum = massiveOfValue.count
            
            resultLog.append("\(massiveOfValue[0])-")
            for i in resultLog {
                logLabel.text = "\(i)"
            }
        }
    
        tappedNummber = false
        
        
    }
    
    //знак делить
    @IBAction func devision(_ sender: UIButton) {
        guard let doubleValue = Double(resultLabel.text!.filter("0123456789.-".contains))  else {return}
        
        massiveOfNumber = ""
        signThis = "division"
        
        if signFirst.isEmpty {
            signFirst = signThis
        }
        
        ///Ставим знак+
        signPlus["minus"] = false
        signPlus["plus"] = false
        signPlus["division"] = true
        signPlus["signСhange"] = false
        signPlus["squareRoot"] = false
        signPlus["square"] = false
        signPlus["percent"] = false
        
        ///проверка того, что мы вводим новые цифры.
        if tappedNummber == true {
            massiveOfValue.append(doubleValue)
            indexSum = massiveOfValue.count
            resultLog.append("\(massiveOfValue[0])÷")
            for i in resultLog {
                logLabel.text = "\(i)"
            }
        }
        
        tappedNummber = false
    }
    
    ///знак умножить
    
    
    @IBAction func squareRoot(_ sender: UIButton) {
        guard let doubleValue = Double(resultLabel.text!.filter("0123456789.-".contains))  else {return}
        
        massiveOfNumber = ""
        signThis = "squareRoot"
        
        if signFirst.isEmpty {
            signFirst = signThis
        }
        
        ///Ставим знак+
        signPlus["minus"] = false
        signPlus["plus"] = false
        signPlus["division"] = false
        signPlus["signСhange"] = false
        signPlus["squareRoot"] = true
        signPlus["square"] = false
        signPlus["percent"] = false
        
        ///проверка того, что мы вводим новые цифры.
        if tappedNummber == true {
            massiveOfValue.append(doubleValue)
            indexSum = massiveOfValue.count
            resultLog.append("\(massiveOfValue[0])×")
            for i in resultLog {
                logLabel.text = "\(i)"
            }
        }
        
  
        tappedNummber = false
        
    }
    
    ///Ставим точку
    @IBAction func dote(_ sender: UIButton) {
        
        var isHave = false
        
        if massiveOfNumber.contains("."){
            isHave = true
        }else{
           isHave = false
        }
        
        if massiveOfNumber.isEmpty {
            massiveOfNumber = massiveOfNumber + "0"
        }
        
        if massiveOfNumber.isEmpty == false && isHave == true {
            resultLabel.text =  massiveOfNumber
        } else {
            guard let number = sender.titleLabel?.text else {return}
            massiveOfNumber =  massiveOfNumber + number
            //resultLabel.text = updateMassive(string: massiveOfNumber)
            resultLabel.text = massiveOfNumber
            tappedNummber = true
        }
        
    }
    
    ///меняем знак
    @IBAction func signChange(_ sender: UIButton) {
        
        var isHave = false
       if massiveOfNumber.contains("-"){
            isHave = true
        }else{
            isHave = false
        }
        
        if result.isEmpty {
            
                if massiveOfNumber.hasPrefix("-") && massiveOfNumber.isEmpty == false  {
                            massiveOfNumber.remove(at: massiveOfNumber.startIndex)
                             resultLabel.text = massiveOfNumber
                } else if massiveOfNumber.isEmpty == false &&  isHave == false  {
                            massiveOfNumber.insert("-", at: massiveOfNumber.startIndex)
                            resultLabel.text = massiveOfNumber
                
                     } else {
                            massiveOfNumber = ""
                        }
        } else {
            if var resultat = result.last {
                //print("when resultat COME = \(resultat)")
                if resultat > 0 && resultat != 0 {
                    resultLabel.text = "\(updateMassive(string: String(0 - resultat)))"
                    resultat = 0 - resultat
                    result.append(resultat)
                    massiveOfValue.removeLast()
                    massiveOfValue.append(resultat)
                    //print("when resultat > 0 = \(resultat)")
                } else if resultat < 0 && resultat != 0 {
                    resultLabel.text = "\(updateMassive(string: String(resultat * (-1.0))))"
                    resultat = resultat * (-1)
                    result.append(resultat)
                    massiveOfValue.removeLast()
                    massiveOfValue.append(resultat)
                    //print("when resultat < 0 = \(resultat)")
                }
            }
        }
        
  }
    
    
    //извлекаем корень
    @IBAction func squarRoot(_ sender: UIButton) {
        if result.isEmpty {
            if let someValue = Double(massiveOfNumber) {
                let resultat = Double(someValue).squareRoot()
                //print("someValue - \(someValue), resultat - \(resultat) ")
                result.append(resultat)
                //mmassiveOfValue.append(resultat)
                resultLabel.text = "\(updateMassive(string: String(resultat)))"
                resultLog.append("√\(someValue) = \(resultat)")
                for i in resultLog {
                    logLabel.text = "\(i)"
                }
            }
        } else {
        
        if let someValue = result.last {
            let resultat = Double(someValue).squareRoot()
             resultLabel.text = "\(updateMassive(string: String(resultat)))"
             result.append(resultat)
             //massiveOfValue.removeLast()
             //massiveOfValue.append(resultat)
            
            resultLog.append("√\(someValue) = \(resultat)")
            for i in resultLog {
                logLabel.text = "\(i)"
            }
        }
        }
        
        
    }
    
    //Квадрат
    @IBAction func square(_ sender: UIButton) {
        if result.isEmpty {
            if let someValue = Double(massiveOfNumber) {
                let resultat = Double(someValue) * Double(someValue)
                result.append(resultat)
                
                //massiveOfValue.append(resultat)
                resultLabel.text = "\(updateMassive(string: String(resultat)))"
                resultLog.append("\(someValue)² = \(resultat)")
                for i in resultLog {
                    logLabel.text = "\(i)"
                }
            }
        } else {
            
            if let someValue = result.last {
                let resultat = Double(someValue) * Double(someValue)
                resultLabel.text = "\(updateMassive(string: String(resultat)))"
                result.append(resultat)
                //massiveOfValue.removeLast()
                //massiveOfValue.append(resultat)
                
                resultLog.append("\(someValue)² = \(resultat)")
                for i in resultLog {
                    logLabel.text = "\(i)"
                }
            }
        }
        
    }
    
    
    
    //percent
    @IBAction func percent(_ sender: UIButton) {
        guard let doubleValue = Double(resultLabel.text!.filter("0123456789.-".contains))  else {return}
        
        massiveOfNumber = ""
        signThis = "percent"
        
        if signFirst.isEmpty {
            signFirst = signThis
        }
        
        ///Ставим знак+
        signPlus["plus"] = false
        signPlus["minus"] = false
        signPlus["division"] = false
        signPlus["signСhange"] = false
        signPlus["squareRoot"] = false
        signPlus["square"] = false
        signPlus["percent"] = true
        
        
        
        ///проверка того, что мы вводим новые цифры.
        if tappedNummber == true {
            massiveOfValue.append(doubleValue)
            indexSum = massiveOfValue.count
            resultLog.append("\(massiveOfValue[0])% from")
            for i in resultLog {
                logLabel.text = "\(i)"
            }
        }
        
        tappedNummber = false
    }
    
    
    
    
    
    @IBAction func resultButton(_ sender: UIButton) {
        
        
       
        var sign = ""
        
       ///определяем знак
        for (key,value) in signPlus {
            if value == true && key == signFirst {
                sign = key
            } else {
                sign = signFirst
            }
            
        }
 
        guard let doubleValue = Double(resultLabel.text!.filter("0123456789.-".contains))  else {return}
         massiveOfNumber = ""
    
           if tappedNummber == true {
            massiveOfValue.append(doubleValue)
            indexSum = massiveOfValue.count
            resultLog.append("\(massiveOfValue[0]) \((sender.titleLabel?.text)!)")
            if resultLog.last == "="{
                resultLog.removeLast()
            }
            for i in resultLog {
                logLabel.text = "\(i)"
            }
        }
        
        ///в зависимости от знака делаем дейтсвия
         if indexSum == 2 && result.isEmpty {
        switch sign {
        case "plus":
            let firtsDouble = Double(massiveOfValue.first!)
            let secondDouble = Double(massiveOfValue.last!)
            let results = firtsDouble + secondDouble
            resultLog.append("\(firtsDouble) + \(secondDouble) = \(results) ")
            result.append(results)
            resultLabel.text = updateMassive(string: String(results))
            indexSum = 0
            massiveOfValue.removeLast()
            massiveOfValue[0] = result[0]
            massiveOfNumber = ""
            for i in resultLog {
                logLabel.text = "\(i)"
            }
            tappedNummber = false
            
            signFirst = ""
            print("signThis = \(signThis),signFirst = \(signFirst) ")
        case "minus":
            let firtsDouble = Double(massiveOfValue.first!)
            let secondDouble = Double(massiveOfValue.last!)
            let results = firtsDouble - secondDouble
            resultLog.append("\(firtsDouble) - \(secondDouble) = \(results) ")
            result.append(results)
            resultLabel.text = updateMassive(string: String(results))
            indexSum = 0
            massiveOfValue.removeLast()
            massiveOfValue[0] = result[0]
            massiveOfNumber = ""
            
            for i in resultLog {
                logLabel.text = "\(i)"
            }
            tappedNummber = false
            
            signFirst = ""
            print("signThis = \(signThis),signFirst = \(signFirst) ")
            case "division":
                
                    let firtsDouble = Double(massiveOfValue.first!)
                    let secondDouble = Double(massiveOfValue.last!)
                    let results = firtsDouble / secondDouble
                    resultLog.append("\(firtsDouble) ÷ \(secondDouble) = \(results) ")
                    result.append(results)
                    resultLabel.text = updateMassive(string: String(results))
                    indexSum = 0
                    massiveOfValue.removeLast()
                    massiveOfValue[0] = result[0]
                    massiveOfNumber = ""
                    
                    for i in resultLog {
                        logLabel.text = "\(i)"
                    }
                    
            tappedNummber = false
            case "squareRoot":
                let firtsDouble = Double(massiveOfValue.first!)
                let secondDouble = Double(massiveOfValue.last!)
                let results = firtsDouble * secondDouble
                resultLog.append("\(firtsDouble) × \(secondDouble) = \(results) ")
                result.append(results)
                resultLabel.text = updateMassive(string: String(results))
                indexSum = 0
                massiveOfValue.removeLast()
                massiveOfValue[0] = result[0]
                massiveOfNumber = ""
                
                for i in resultLog {
                    logLabel.text = "\(i)"
            }
            tappedNummber = false
            case "percent":
                let firtsDouble = Double(massiveOfValue.first!)
                let secondDouble = Double(massiveOfValue.last!)
                let results = firtsDouble * secondDouble / 100
                //print("first =\(results)=\(firtsDouble)+\(secondDouble)")
                resultLog.append("\(firtsDouble) % from \(secondDouble) = \(results) ")
                result.append(results)
                resultLabel.text = updateMassive(string: String(results))
                indexSum = 0
                massiveOfValue.removeLast()
                massiveOfValue[0] = result[0]
                massiveOfNumber = ""
                
                for i in resultLog {
                    logLabel.text = "\(i)"
            }
            tappedNummber = false
        default:
            break
        }
        
        }
        
        if indexSum == 2 && result.isEmpty == false {
            switch sign {
            case "plus":
                let results = massiveOfValue[0] + massiveOfValue[1]
                resultLog.append("\(massiveOfValue[0]) + \(massiveOfValue[1]) = \(results) ")
                result.append(results)
                resultLabel.text = updateMassive(string: String(results))
                indexSum = 0
                massiveOfValue.removeLast()
                massiveOfValue[0] = result.last!
                massiveOfNumber = ""
                for i in resultLog {
                    logLabel.text = "\(i)"
                }
                tappedNummber = false
                signFirst = ""
                print("signThis = \(signThis),signFirst = \(signFirst) ")
                case "minus":
                    let results = massiveOfValue[0] - massiveOfValue[1]
                    resultLog.append("\(massiveOfValue[0]) - \(massiveOfValue[1]) = \(results) ")
                    result.append(results)
                    resultLabel.text = updateMassive(string: String(results))
                    indexSum = 0
                    massiveOfValue.removeLast()
                    massiveOfValue[0] = result.last!
                    massiveOfNumber = ""
                    
                    for i in resultLog {
                        logLabel.text = "\(i)"
                }
                tappedNummber = false
                signFirst = ""
            case "division":
                let results = massiveOfValue[0] / massiveOfValue[1]
                resultLog.append("\(massiveOfValue[0]) ÷ \(massiveOfValue[1]) = \(results) ")
                result.append(results)
                resultLabel.text = updateMassive(string: String(results))
                indexSum = 0
                massiveOfValue.removeLast()
                massiveOfValue[0] = result.last!
                massiveOfNumber = ""
                
                for i in resultLog {
                    logLabel.text = "\(i)"
                }
            
            tappedNummber = false
            case "squareRoot":
            let firtsDouble = Double(massiveOfValue.first!)
            let secondDouble = Double(massiveOfValue.last!)
            let results = firtsDouble * secondDouble
            resultLog.append("\(firtsDouble) × \(secondDouble) = \(results) ")
            result.append(results)
            resultLabel.text = updateMassive(string: String(results))
            indexSum = 0
            massiveOfValue.removeLast()
            massiveOfValue[0] = result.last!
            massiveOfNumber = ""
            
            for i in resultLog {
                logLabel.text = "\(i)"
            }
                tappedNummber = false
            case "percent":
                let results = massiveOfValue[0] * massiveOfValue[1] / 100
                resultLog.append("\(massiveOfValue[0]) % from \(massiveOfValue[1]) = \(results) ")
                result.append(results)
                print("second = \(results)=\(massiveOfValue[0])+\(massiveOfValue[1])")
                resultLabel.text = updateMassive(string: String(results))
                indexSum = 0
                massiveOfValue.removeLast()
                massiveOfValue[0] = result.last!
                massiveOfNumber = ""
                
                for i in resultLog {
                    logLabel.text = "\(i)"
                }
            
            tappedNummber = false
                
            default:
                break
            }
        }
        
        
        
        
        tappedNummber = false
        
    
    
    
    
   
    }
    
}
