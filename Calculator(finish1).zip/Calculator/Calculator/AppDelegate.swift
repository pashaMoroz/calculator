//
//  AppDelegate.swift
//  Calculator
//
//  Created by Pasha Moroz on 3/14/19.
//  Copyright © 2019 Pavel Moroz. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?




}

